AddCSLuaFile("elecrash/cl_elecrash.lua") -- { user_id }


include("elecrash/sv_elecrash.lua")